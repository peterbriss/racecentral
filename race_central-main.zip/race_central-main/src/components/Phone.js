export default function Phone() {
  return (
    <a href="tel:+15553334444" className="m-2 flex items-center">
      <p className="ml-2">Phone: 15553334444</p>
    </a>
  )
}
