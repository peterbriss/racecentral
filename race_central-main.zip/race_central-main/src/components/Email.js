export default function Email() {
  return (
    <a href="mailto:host@racecentral.live" className="m-2 flex items-center">
      <p className="ml-2">Email: host@racecentral.live</p>
    </a>
  )
}
